# Data folder

Put KITTI Object Detection data here:

```text
data/kitti_object/training/
  image_2/
  velodyne/
  calib/
  label_2/
```

For smoke testing without KITTI:

```bash
python scripts/00_make_toy_kitti.py --out_dir data/toy_kitti/training --num_frames 24
```
